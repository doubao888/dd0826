import React from 'react';
import PropTypes from 'prop-types';
import zhCN from 'antd/lib/locale-provider/zh_CN';
import { Spin, message, LocaleProvider } from 'antd';
import { connect } from 'dva';
import SearchOrder from './SearchOrder';
import parse from 'url-parse';
import './less/publicLayout.less';

import{ Link} from 'react-router-dom';


class PublicLayout extends React.Component {

  static propTypes = {
    form: PropTypes.shape({
      validateFields: PropTypes.func.isRequired,
      getFieldDecorator: PropTypes.func.isRequired,
      resetFields: PropTypes.func.isRequired,
      setFieldsValue: PropTypes.func.isRequired
    }).isRequired,
  }

  static defaultProps = {
  }

  constructor(props) {
    super(props);

    const url = parse(props.location.search, true);
    const { traffic, categoryId, result } = url.query;
    if (traffic) {
      sessionStorage.setItem('traffic', traffic);
    }
    if (result) {
      this.props.dispatch({ type: 'game/aliPay', payload: { mid: Math.random() } });
    }
    const entry = window.location.hostname.split('.')[0];
    sessionStorage.setItem('entry', entry);
    this.state = {
      showMyOrderModal: false,
      parentTypeArr: [],
      childrenTypeArr: [],
      allTypeArr: [],
      categoryId: categoryId,
      goodsName: '',
      isShowDouYuLogo: entry === 'douyu' ? true : false,
      breadCrumbsObj: sessionStorage.getItem('breadCrumbsObj') ? JSON.parse(sessionStorage.getItem('breadCrumbsObj')) : [{
        id: '',
        name: '首页',
        level: 1
      }],
      channelImg: ''
    };
  }


  componentWillMount() {
    this.props.dispatch({
      type: 'game/getList', payload: {
        entry: sessionStorage.getItem('entry')
      }
    });
    this.props.dispatch({
      type: 'game/channelimg', payload: {
        entry: sessionStorage.getItem('entry')
      }
    });

    // if(this.props.history)

  }

  componentWillReceiveProps(nextProps) {
    const { props } = this;
    // console.log('nextProps', nextProps);
    const { game } = nextProps;
    const { getListResult, channelimgResult } = game;
    const { goodsName, categoryId, breadCrumbsObj } = this.state;
    let cid = categoryId ? categoryId : '';
    if (game.mid !== props.game.mid) {
      this.showMyOrderModal();
    }
    if (props.game.getListResult !== getListResult) {
      const { code, data } = getListResult;
      if (code === '0') {
        let parentTypeArr = [];
        for (let index = 0; index < data.length; index++) {
          const element = data[index];
          if (element.parentId === '0') {
            parentTypeArr.push({ id: element.id, name: element.name });
          }
        }
        if (this.props.location.pathname === '/') {

          this.setState({
            categoryId: cid,
            goodsName: ''
          }, () => {
            if (cid) {
              this.loadCategoryInfo(data, parentTypeArr, cid);
            }
            this.props.history.push({ pathname: cid ? `/?categoryId=${cid}` : '/', state: { goodsName: '', categoryId: cid } });
          });
        }

        return this.setState({
          parentTypeArr,
          allTypeArr: data,
        });
      }
      message.error(getListResult.message);
    }
    if (game.getGameListMid !== props.game.getGameListMid) {
      this.props.history.push({ pathname: cid ? `/?categoryId=${cid}` : '/', state: { goodsName, categoryId: cid } });
    }
    if (channelimgResult !== props.game.channelimgResult) {
      const { code, data } = game.channelimgResult;
      if (code === "0") {
        return this.setState({
          channelImg: data
        });
      }
      message.error(channelimgResult.message);
    }
    if (game.getVgGameGoods !== props.game.getVgGameGoods) {
      const { code, data } = game.getVgGameGoods;
      if (code === "0") {
        if (breadCrumbsObj[breadCrumbsObj.length - 1].level === 4) {
          breadCrumbsObj[breadCrumbsObj.length - 1] = {
            name: data.goodsName,
            id: data.goodsId,
            level: 4
          };
        }
        else {
          breadCrumbsObj[breadCrumbsObj.length] = {
            name: data.goodsName,
            id: data.goodsId,
            level: 4
          };
        }
        return sessionStorage.setItem("breadCrumbsObj", JSON.stringify(breadCrumbsObj));
      }
      message.error(data.message);
    }
  }
  showMyOrderModal = () => {
    this.setState({
      showMyOrderModal: true
    });
  }
  closeMyOrderModal = () => {
    this.setState({
      showMyOrderModal: false
    });
  }
  loadCategoryInfo = (allType, parentType, cid) => {
    let isLevelOne = false;
    // 1.判断是不是一级分类
    for (let index = 0; index < parentType.length; index++) {
      const element = parentType[index];
      if (element.id === cid) {
        element.isClick = true;
        isLevelOne = true;
        this.getChildTypeArr('isFirst', element, isLevelOne);
      }
    }
    // 如果是不一级分类
    if (!isLevelOne) {
      for (let index = 0; index < allType.length; index++) {
        const element = allType[index];
        if (element.id === cid) {
          const parentId = element.parentId;
          for (let j = 0; j < parentType.length; j++) {
            const nowData = parentType[j];
            if (nowData.id === parentId) {
              nowData.isClick = true;
              this.getChildTypeArr('isFirst', nowData, isLevelOne, cid);
            }
          }
        }
      }
    }
    this.setState({
      parentType
    });
  }
  getChildTypeArr = (isFirst, item, isLevelOne, cid) => {
    const { allTypeArr, breadCrumbsObj, parentTypeArr } = this.state;
    if (!item) {
      breadCrumbsObj.length = 1;
      breadCrumbsObj[0] = {
        name: '首页',
        id: '',
        level: 1
      };
      return this.setState({
        categoryId: '',
        childrenTypeArr: [],
        breadCrumbsObj
      }, () => {
        sessionStorage.setItem("breadCrumbsObj", JSON.stringify(breadCrumbsObj));
        if (!isFirst) {
          this.props.dispatch({ type: 'game/searchGameList', payload: { getGameListMid: Math.random() } });
        }
      });
    }
    breadCrumbsObj.length = 2;
    breadCrumbsObj[1] = {
      name: item.name,
      id: item.id,
      level: 2
    };
    sessionStorage.setItem("breadCrumbsObj", JSON.stringify(breadCrumbsObj));
    // 点击变色
    for (let index = 0; index < parentTypeArr.length; index++) {
      const element = parentTypeArr[index];
      element.isClick = false;
      if (element.id === item.id) {
        element.isClick = true;
      }
    }
    let childrenTypeArr = [];
    for (let index = 0; index < allTypeArr.length; index++) {
      const element = allTypeArr[index];
      if (element.parentId === item.id) {
        childrenTypeArr.push({
          id: element.id,
          name: element.name,
        });
      }
    }
    this.setState({
      childrenTypeArr,
      breadCrumbsObj,
      parentTypeArr,
      // 如果isLelve
      categoryId: isLevelOne ? item.id : cid
    }, () => {
      if (!isFirst) {
        this.props.dispatch({ type: 'game/searchGameList', payload: { getGameListMid: Math.random() } });
      }
    });
  }
  childrenTypeClick = (item) => {
    const { breadCrumbsObj } = this.state;
    breadCrumbsObj[2] = {
      name: item.name,
      id: item.id,
      level: 3
    };
    sessionStorage.setItem("breadCrumbsObj", JSON.stringify(breadCrumbsObj));
    this.setState({
      categoryId: item.id,
      breadCrumbsObj
    }, () => {
      this.props.dispatch({ type: 'game/searchGameList', payload: { getGameListMid: Math.random() } });
    });
  }
  keyDownSearch = (event) => {
    if (event.keyCode == 13) {
      this.props.dispatch({ type: 'game/searchGameList', payload: { getGameListMid: Math.random() } });
    }
  }
  changeSearchInfo = (e) => {
    this.setState({
      goodsName: e.target.value
    });
  }
  searchGameList = () => {
    this.props.dispatch({ type: 'game/searchGameList', payload: { getGameListMid: Math.random() } });
  }
  toLink = (item) => {
    const { goodsName, breadCrumbsObj } = this.state;
    if (item.level !== 4) {
      breadCrumbsObj.length = item.level;
      this.setState({
        breadCrumbsObj
      });
      sessionStorage.setItem("breadCrumbsObj", JSON.stringify(breadCrumbsObj));
      return this.props.history.push({ pathname: '/', state: { goodsName, categoryId: item.id } });
    }
  }
  render() {
    const { showMyOrderModal, parentTypeArr, childrenTypeArr, categoryId, breadCrumbsObj, channelImg } = this.state;
    return (
      <div className="parent-container">
        <Spin spinning={!!this.props.loading.models.game}>
          <div className="header">
            <div className="header-top">
              <div className="w-content clearfix">
                <div className="header-top-left">
                  <span className="g-logo"></span>
                  {channelImg && <span className="douyu-logo" style={{ backgroundImage: `url(${channelImg})` }}></span>}
                </div>
                <div className="header-top-right">
                  <div className="user-info">
                    <span className="online-qq">
                      <Link target="_blank" style={{ color: '#bfbfbf' }} to="/helpList">常见问题
                      </Link>
                    </span>
                    <button className="btn btn-orange" onClick={this.showMyOrderModal}>我的订单</button>
                  </div>
                </div>
              </div>
            </div>
            <div className="header-menu-bottom w-content clearfix">
              <div className="type-name">
                <ul className="header-nav">
                  <li className={categoryId === '' ? "nav-active" : 'nav'} onClick={() => this.getChildTypeArr()}>
                    <a>首页</a>
                  </li>
                  {parentTypeArr.map((item) => (
                    <li className={categoryId !== '' && item.isClick ? "nav-active" : 'nav'} onClick={() => this.getChildTypeArr('', item, true)}>
                      <a>{item.name}</a>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="public-serach">
                <span href="#" className="serach-btn" onClick={this.searchGameList}></span>
                <input
                  type="text"
                  placeholder="请输入商品关键词搜索"
                  onKeyDown={this.keyDownSearch}
                  onChange={this.changeSearchInfo}
                  className="input-text"
                />
              </div>
            </div>
            {childrenTypeArr.length ? <div className="goods-type">
              <div className="w-content">
                <ul className="clearfix">
                  {childrenTypeArr.map((item) => (
                    <li onClick={() => this.childrenTypeClick(item)}>
                      <a className="goodsNameUl">{item.name}</a>
                    </li>
                  ))}
                </ul>
              </div>
            </div> : ''}
          </div>
          {this.props.location.pathname.indexOf('gameDetail') !== -1 && <div className="bread-crumbs w-content clearfix">
            {breadCrumbsObj.map((item) => {
              return <div><a onClick={() => this.toLink(item)}>{item.name}</a>{item.level !== 4 && <span>></span>}</div>
            })}
          </div>}
          {/* 主体 */}
          <div className="container w-content clearfix" id="mainContent">
            <LocaleProvider locale={zhCN}>
              {this.props.children}
            </LocaleProvider>
          </div>
          <div className="footer">
            <div className="copyright">
              <p>Copyright©2017 武汉搜卡科技有限公司all rights reserved.
              <a style={{ color: '#35475e' }} href="http://www.fulu.com/"></a>
              </p>
              <p>【网络文化经营许可证】鄂网文〔2017〕8164-174号 | 鄂ICP备17017790号-2 </p>
              <p> 商务合作邮箱：caixiaokang@fulu.com</p>
            </div>
          </div>
          {/* 查询订单Modal */}
          {showMyOrderModal &&
            <SearchOrder
              history={this.props.history}
              closeMyOrderModal={this.closeMyOrderModal}
            />
          }
        </Spin>

        <div className="qq-btn">
          <a className='top-isuue' href='/helpList' target='_blank'>常见问题</a>
          <div className="top-icon">
            <a target="_blank" title="QQ在线客服" href="http://wpa.qq.com/msgrd?v=3&uin=2379581731&site=qq&menu=yes">
            </a>
          </div>
        </div>
      </div>
    );
  }
}



const mapStateToProps = (state) => {
  return {
    ...state,
  };
}

export default connect(mapStateToProps)(PublicLayout);

