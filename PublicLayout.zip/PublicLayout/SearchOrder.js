import React from 'react';
import PropTypes from 'prop-types';
import dva, { connect } from 'dva';
import { Input, Spin, Modal, Button, Form, Row, Col, Checkbox, message } from 'antd';
import './less/publicLayout.less';

const createForm = Form.create;
const FormItem = Form.Item;

const tel = /^1(3|4|5|6|7|8|9)\d{9}$/;

class SearchOrder extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      sendCodeTime: 0,
      phone: '',
      code: ''
    }
  }
  componentWillReceiveProps(nextProps) {
    const { props } = this;
    const { game } = nextProps;
    const { code, phone } = this.state;
    if (game.sendMobileCode !== props.game.sendMobileCode) {
      const { code } = game.sendMobileCode;
      if (code === "0") {
        message.success(game.sendMobileCode.message);
        this.SendCode();
      } else {
        message.error(game.sendMobileCode.message);
        this.SendCode();
      }
    }
    if (game.checkCodeResult !== props.game.checkCodeResult) {
      const codeNum = game.checkCodeResult.code;
      if (codeNum === "0") {
        const { pathname } = window.location;
        if (pathname.indexOf('gameOrder') !== -1) {
          return window.location.href = `/gameOrder?code=${code}&phone=${phone}`;
        }
        this.props.history.push(`/gameOrder?code=${code}&phone=${phone}`);
        this.props.closeMyOrderModal();
      } else {
        message.error(game.checkCodeResult.message);
      }
    }
  }
  SendMobileCode = () => {
    const phone = this.props.form.getFieldValue('phone');
    if (!phone || !tel.test(phone)) {
      message.error('请输入正确的手机号！')
      return;
    }
    this.props.dispatch({
      type: 'game/sendMobileCode', payload: {
        Mobile: phone.replace(/\s/g, ''),
        Type: 'searchorder'
      }
    });
  }
  SendCode = () => {
    const self = this;
    this.setState({
      sendCodeTime: 60
    })
    const sendCodeTimeAction = setInterval(() => {
      let { sendCodeTime } = this.state;
      if (sendCodeTime === 1) {
        clearInterval(sendCodeTimeAction)
      }
      sendCodeTime -= 1
      self.setState({
        sendCodeTime
      })
    }, 1000);
  }
  componentWillUnmount() {
    if (this.sendCodeTimeAction)
      clearInterval(this.sendCodeTimeAction);
  }
  handleOk = () => {
    this.props.form.validateFields((err, values) => {
      if (err) {
        return;
      } else {
        this.setState({
          ...values
        });
        this.props.dispatch({
          type: 'game/checkCode', payload: {
            mobile: (values.phone).replace(/\s/g, ''),
            code: values.code.replace(/\s/g, ''),
            Type: 'searchorder'
          }
        });
      }
    })
  }
  checkPhone = (rule, value, callback) => {
    if (value && !tel.test(value)) {
      callback('请输入正确的手机号');
    }
    callback();
  }
  render() {
    const { props } = this;
    const { sendCodeTime } = this.state;
    const { getFieldDecorator } = props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        offset: 6,
      },
    };
    return (
      <div>
        <Modal
          width={470}
          visible
          onCancel={props.closeMyOrderModal}
          title={null}
          footer={null}
        >
          <Spin spinning={!!this.props.loading.models.game}>
            <div className="search-order">
              <div className="search-order-title modal-title">查询订单</div>
              <Form>
                <FormItem {...formItemLayout} label={'手机号码'}>
                  {
                    getFieldDecorator('phone', {
                      rules: [
                        { required: true, message: '手机号码不能为空' },
                        { validator: this.checkPhone }
                      ],
                      initialValue: ''
                    })(
                      <Input maxLength={11} />
                    )}
                </FormItem>
                <FormItem {...formItemLayout} label={'验证码'}>
                  {
                    getFieldDecorator('code', {
                      rules: [
                        { required: true, message: '验证码不能为空' }
                      ],
                      initialValue: ''
                    })(
                      <Input
                        addonAfter={
                          <Button
                            onClick={() => { this.SendMobileCode() }}
                            disabled={!!(sendCodeTime > 1)}
                          >
                            {sendCodeTime > 1 ? <span>重新获取({sendCodeTime}s)</span> : '获取验证码'}
                          </Button>
                        }
                      />
                    )}
                </FormItem>
                <FormItem {...tailFormItemLayout}>
                  <Button
                    type="primary"
                    size="large"
                    style={{ width: '245px' }}
                    className="btn-theme"
                    onClick={() => { this.handleOk(); }}
                  >确定</Button>
                </FormItem>
              </Form>
            </div>
          </Spin>
        </Modal>
      </div>
    );
  }
}


const mapStateToProps = (state) => {
  return {
    ...state,
  };
}

export default connect(mapStateToProps)(createForm()(SearchOrder));
