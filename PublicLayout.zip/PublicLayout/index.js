import PublicLayout from './PublicLayout';

export default PublicLayout;
